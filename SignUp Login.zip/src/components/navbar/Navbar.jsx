import React from 'react'
import "./Navbar.css"
import {Link,NavLink} from "react-router-dom"

function Navbar() {
  return (
    <div className='nav' >
        <div className="container">
            <nav className="navbar">
                <h1>MyMoney</h1>
                <ul>
                    <li><NavLink to={"/signUp"} >Singn Up</NavLink></li>
                    <li><NavLink to={"/login"} >Login</NavLink></li>
                </ul>
            </nav>
        </div>
    </div>
  )
}

export default Navbar