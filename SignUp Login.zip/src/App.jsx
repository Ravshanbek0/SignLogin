import React from 'react'
import './App.css'
import {BrowserRouter,Route,Routes} from "react-router-dom"
import Navbar from './components/navbar/Navbar'
import SignUp from './pages/Sign up/SignUp'
import Login from './pages/Login/Login'

function App() {
  return (
    <div>
      <BrowserRouter>
        <Navbar/>
        <Routes>
          <Route path='/signUp' element={<SignUp/>} />
          <Route path='/login' element={<Login/>} />
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App