import React from 'react'

function Login() {
  return (
    <div className='signUp'>
      <form className="sign-form">
        <label htmlFor="">email:</label>
        <input type="text" placeholder='emailni kiriting...' />
        <label htmlFor="">password:</label>
        <input type="text" placeholder='password kiriting...' />
        <button>Login</button>
      </form>
    </div>
  )
}

export default Login