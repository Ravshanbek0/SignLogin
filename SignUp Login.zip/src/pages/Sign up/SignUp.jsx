import React from 'react'
import './SignUp.css'

function SignUp() {
  return (
    <div className='signUp'>
      <form className="sign-form">
        <label htmlFor="">email:</label>
        <input type="text" placeholder='emailni kiriting...' />
        <label htmlFor="">password:</label>
        <input type="text" placeholder='password kiriting...' />
        <label htmlFor="">displayName:</label>
        <input type="text" placeholder='ismingizni kiriting...' />
        <button>Sing Up</button>
      </form>
    </div>
  )
}

export default SignUp